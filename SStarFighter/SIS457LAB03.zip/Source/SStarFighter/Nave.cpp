// Fill out your copyright notice in the Description page of Project Settings.


#include "Nave.h"
#include "Components/StaticMeshComponent.h"
#include "Components/CapsuleComponent.h"

// Sets default values
ANave::ANave()
{
 	// Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	AutoPossessPlayer = EAutoReceiveInput::Player0;

	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootComponent"));

	NaveMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Nave Mesh"));
	CapsuleCollision = CreateDefaultSubobject<UCapsuleComponent>(TEXT("Capsule Collision"));

	NaveMesh->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);
	CapsuleCollision->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);

	MaxVelocity = 500.0f;
	Current_X_Velocity = 0.0f;
	Current_Y_Velocity = 0.0f;

}

// Called when the game starts or when spawned
void ANave::BeginPlay()
{
	Super::BeginPlay();

	Current_Location = this->GetActorLocation();

	OnActorBeginOverlap.AddDynamic(this, &ANave::OnBeginOverLap);
	
}

// Called every frame
void ANave::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (Current_X_Velocity != 0.0f || Current_Y_Velocity != 0.0f)
	{
		New_Location = FVector(Current_Location.X + (Current_X_Velocity * DeltaTime), 
			Current_Location.Y + (Current_Y_Velocity * DeltaTime), 0);

		this->SetActorLocation(New_Location);
		
		Current_Location = New_Location;

	}

	if (this->GetActorLocation().X > Field_Width)
	{
		Current_Location = FVector(Field_Width - 1, Current_Location.Y, Current_Location.Z);

	}

	if (this->GetActorLocation().X < -Field_Width)
	{
		Current_Location = FVector(-Field_Width + 1, Current_Location.Y, Current_Location.Z);

	}

	if (this->GetActorLocation().Y > Field_Height)
	{
		Current_Location = FVector(Current_Location.X, Field_Height - 1, Current_Location.Z);

	}

	if (this->GetActorLocation().Y < -Field_Height)
	{
		Current_Location = FVector(Current_Location.X, -Field_Height + 1, Current_Location.Z);

	}

}

// Called to bind functionality to input
void ANave::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	PlayerInputComponent->BindAxis(FName("MoveUp"), this, &ANave::MoveUp);
	PlayerInputComponent->BindAxis(FName("MoveRight"), this, &ANave::MoveRight);

}

void ANave::MoveUp(float AxisValue)
{
	Current_X_Velocity = MaxVelocity * AxisValue;
}

void ANave::MoveRight(float AxisValue)
{
	Current_Y_Velocity = MaxVelocity * AxisValue;

}

void ANave::OnBeginOverLap(AActor* PlayerActor, AActor* OtherActor)
{
}

