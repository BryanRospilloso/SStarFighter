// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Enemigo_Terrestre.h"
#include "Enemigo_Terrestre1.generated.h"

UCLASS()
class SSTARFIGHTER_API AEnemigo_Terrestre1 : public AEnemigo_Terrestre
{
	GENERATED_BODY()

public:
	AEnemigo_Terrestre1();
	
};
