// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Enemigo_Acuatico.h"
#include "Enemigo_Acuatico1.generated.h"

UCLASS()
class SSTARFIGHTER_API AEnemigo_Acuatico1 : public AEnemigo_Acuatico
{
	GENERATED_BODY()

public:
	AEnemigo_Acuatico1();
	
};
