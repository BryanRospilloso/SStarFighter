// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Pawn.h"
#include "Nave.generated.h"

class UStaticMeshComponent;
class UCapsuleComponent;

UCLASS()
class SSTARFIGHTER_API ANave : public APawn
{
	GENERATED_BODY()

public:
	// Sets default values for this pawn's properties
	ANave();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	UPROPERTY(EditAnywhere)
		UStaticMeshComponent* NaveMesh;

	UPROPERTY(EditAnywhere)
		UCapsuleComponent* CapsuleCollision;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	void MoveUp(float AxisValue);

	void MoveRight(float AxisValue);

	UPROPERTY(EditAnywhere)
		float MaxVelocity;

	float Current_X_Velocity;
	float Current_Y_Velocity;

	FVector Current_Location;
	FVector New_Location;

	UFUNCTION()
		void OnBeginOverLap(AActor* PlayerActor, AActor* OtherActor);

	UPROPERTY(EditAnywhere)
		float Field_Width;

	UPROPERTY(EditAnywhere)
		float Field_Height;

};
