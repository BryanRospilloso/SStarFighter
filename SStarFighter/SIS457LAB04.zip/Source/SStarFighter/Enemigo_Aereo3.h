// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Enemigo_Aereo.h"
#include "Enemigo_Aereo3.generated.h"

UCLASS()
class SSTARFIGHTER_API AEnemigo_Aereo3 : public AEnemigo_Aereo
{
	GENERATED_BODY()

public:
	AEnemigo_Aereo3();
	
};
