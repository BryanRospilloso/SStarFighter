// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Enemigo_Aereo.h"
#include "Enemigo_Aereo1.generated.h"

UCLASS()
class SSTARFIGHTER_API AEnemigo_Aereo1 : public AEnemigo_Aereo
{
	GENERATED_BODY()

public:
	AEnemigo_Aereo1();
	
};
